#include <kipr/botball.h>
void wow(int r, int l, int u){
motor(3,r);
motor(0,l);
msleep(u);
}


int main()
{
 //left wheel on A  
    
    //1
    wow(55,50,1500);

    wow(0,52,3000);
    
   // forward after 1
   wow(55,50,1800); //touches 2
   
    wow(0, 50, 4600); //touches 3

    
    //forward to 4
    
    wow(55,50,3000); //touches 4
    
    //turn to 5
    
    wow(50,0,4200);
    
    wow(55,50,4000);//touches 6 and 7
 
    wow(0,50,3500);//touches 8

    wow(55,50,3500);
 
    wow(50,0,4200);
  
    wow(55,50,1500);
  
    wow(50,0,1500);
  
    return 0;
}
